-- TABLE: active_guests
CREATE TABLE `active_guests` (
  `ip` varchar(15) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- TABLE: active_users
CREATE TABLE `active_users` (
  `username` varchar(30) NOT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `active_users` (`username`, `timestamp`) VALUES ('admin', '1461152556');

-- TABLE: categories
CREATE TABLE `categories` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `categoryName` varchar(255) DEFAULT '0',
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
INSERT INTO `categories` (`id`, `categoryName`, `status`) VALUES ('1', 'Switches', '1');
INSERT INTO `categories` (`id`, `categoryName`, `status`) VALUES ('2', 'Routers', '1');
INSERT INTO `categories` (`id`, `categoryName`, `status`) VALUES ('4', 'LoadBalancers', '1');
INSERT INTO `categories` (`id`, `categoryName`, `status`) VALUES ('5', 'WANOptimizers', '1');
INSERT INTO `categories` (`id`, `categoryName`, `status`) VALUES ('8', 'Firewalls', '1');

-- TABLE: cmdCatTbl
CREATE TABLE `cmdCatTbl` (
  `configCmdId` int(10) DEFAULT NULL,
  `nodeCatId` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('160', '1');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('160', '2');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('160', '4');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('160', '5');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('160', '8');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('161', '1');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('161', '2');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('161', '4');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('161', '5');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('161', '8');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('163', '1');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('163', '2');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('164', '1');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('164', '2');
INSERT INTO `cmdCatTbl` (`configCmdId`, `nodeCatId`) VALUES ('165', '2');

-- TABLE: compliancePolElem
CREATE TABLE `compliancePolElem` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `elementName` varchar(255) NOT NULL,
  `elementDesc` varchar(255) NOT NULL,
  `singleParam1` int(10) DEFAULT NULL COMMENT '1, equals. 2, contains',
  `singleLine1` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `compliancePolElem` (`id`, `elementName`, `elementDesc`, `singleParam1`, `singleLine1`, `status`) VALUES ('1', 'new element', 'element description', '1', 'show ip int bried', '1');
INSERT INTO `compliancePolElem` (`id`, `elementName`, `elementDesc`, `singleParam1`, `singleLine1`, `status`) VALUES ('2', 'another elem', 'another elem desc', '1', 'ntp server 1.1.1.1', '1');

-- TABLE: compliancePolElemTbl
CREATE TABLE `compliancePolElemTbl` (
  `polId` int(10) DEFAULT NULL,
  `elemId` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
INSERT INTO `compliancePolElemTbl` (`polId`, `elemId`) VALUES ('1', '2');
INSERT INTO `compliancePolElemTbl` (`polId`, `elemId`) VALUES ('1', '1');

-- TABLE: compliancePolicies
CREATE TABLE `compliancePolicies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `policyName` varchar(255) DEFAULT NULL,
  `policyDesc` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `compliancePolicies` (`id`, `policyName`, `policyDesc`, `status`) VALUES ('1', 'A New Policy', 'Policy Description', '1');

-- TABLE: complianceReportPolTbl
CREATE TABLE `complianceReportPolTbl` (
  `reportId` int(10) DEFAULT NULL,
  `polId` int(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=FIXED;
INSERT INTO `complianceReportPolTbl` (`reportId`, `polId`) VALUES ('1', '1');
INSERT INTO `complianceReportPolTbl` (`reportId`, `polId`) VALUES ('2', '1');

-- TABLE: complianceReports
CREATE TABLE `complianceReports` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `reportsName` varchar(255) DEFAULT NULL,
  `reportsDesc` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
INSERT INTO `complianceReports` (`id`, `reportsName`, `reportsDesc`, `status`) VALUES ('1', 'New Policy Report', 'policy report desc', '1');
INSERT INTO `complianceReports` (`id`, `reportsName`, `reportsDesc`, `status`) VALUES ('2', 'anopther pol report', 'another test pol report', '1');

-- TABLE: configcommands
CREATE TABLE `configcommands` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `command` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=latin1;
INSERT INTO `configcommands` (`id`, `command`, `status`) VALUES ('160', 'show running-config', '1');
INSERT INTO `configcommands` (`id`, `command`, `status`) VALUES ('161', 'show startup-config', '1');
INSERT INTO `configcommands` (`id`, `command`, `status`) VALUES ('163', 'show cdp neigh', '1');
INSERT INTO `configcommands` (`id`, `command`, `status`) VALUES ('164', 'show ip access-list', '1');
INSERT INTO `configcommands` (`id`, `command`, `status`) VALUES ('165', 'show ip route', '1');

-- TABLE: configs
CREATE TABLE `configs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `deviceId` int(10) DEFAULT NULL,
  `configLocation` varchar(255) DEFAULT NULL,
  `configFilename` varchar(255) DEFAULT NULL,
  `configDate` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
INSERT INTO `configs` (`id`, `deviceId`, `configLocation`, `configFilename`, `configDate`) VALUES ('1', '2', '/test/', '', '2015-04-18');
INSERT INTO `configs` (`id`, `deviceId`, `configLocation`, `configFilename`, `configDate`) VALUES ('2', '2', '/tetete/', '', '2015-04-18');
INSERT INTO `configs` (`id`, `deviceId`, `configLocation`, `configFilename`, `configDate`) VALUES ('3', '2', '/tetete/', '', '2015-04-18');

-- TABLE: configtemplates
CREATE TABLE `configtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `templateName` varchar(50) NOT NULL,
  `templateDesc` varchar(50) NOT NULL,
  `template` mediumtext NOT NULL,
  `templateVars` mediumtext NOT NULL,
  `templateVarSyms` mediumtext NOT NULL,
  `templateVarSubs` mediumtext NOT NULL,
  `newTemplate` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- TABLE: devicesaccessmethod
CREATE TABLE `devicesaccessmethod` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `devicesAccessMethod` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `devicesaccessmethod` (`id`, `devicesAccessMethod`) VALUES ('1', 'Telnet');
INSERT INTO `devicesaccessmethod` (`id`, `devicesAccessMethod`) VALUES ('3', 'SSHv2');

-- TABLE: generatedConfigs
CREATE TABLE `generatedConfigs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `configName` varchar(50) NOT NULL,
  `templateName` varchar(50) NOT NULL,
  `configDesc` varchar(50) NOT NULL,
  `linkedId` int(11) NOT NULL,
  `newConfig` mediumtext NOT NULL,
  `configLocation` varchar(100) NOT NULL,
  `configFilename` varchar(100) NOT NULL,
  `configDate` date NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- TABLE: nodes
CREATE TABLE `nodes` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `deviceName` varchar(255) DEFAULT NULL,
  `deviceUsername` varchar(255) DEFAULT NULL,
  `devicePassword` varchar(255) DEFAULT NULL,
  `deviceEnableMode` varchar(255) DEFAULT NULL,
  `deviceEnablePassword` varchar(255) DEFAULT NULL,
  `deviceAccessMethodId` varchar(100) DEFAULT NULL,
  `deviceIpAddr` varchar(255) DEFAULT NULL,
  `devicePrompt` varchar(255) DEFAULT NULL,
  `nodeCatId` int(10) DEFAULT NULL,
  `vendorId` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `termLength` int(2) DEFAULT NULL,
  `nodeVersion` varchar(255) DEFAULT NULL,
  `nodeAddedBy` varchar(255) DEFAULT '-',
  `defaultCreds` int(1) DEFAULT NULL,
  `defaultUsername` varchar(255) DEFAULT NULL,
  `defaultPassword` varchar(255) DEFAULT NULL,
  `defaultEnablePassword` varchar(255) DEFAULT NULL,
  `deviceDateAdded` date DEFAULT NULL,
  `deviceLastUpdated` date DEFAULT NULL,
  `connPort` int(2) DEFAULT NULL,
  `status` int(10) DEFAULT '1',
  `custom_Location` varchar(255) DEFAULT NULL COMMENT 'Custom Property - Location',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
INSERT INTO `nodes` (`id`, `deviceName`, `deviceUsername`, `devicePassword`, `deviceEnableMode`, `deviceEnablePassword`, `deviceAccessMethodId`, `deviceIpAddr`, `devicePrompt`, `nodeCatId`, `vendorId`, `model`, `termLength`, `nodeVersion`, `nodeAddedBy`, `defaultCreds`, `defaultUsername`, `defaultPassword`, `defaultEnablePassword`, `deviceDateAdded`, `deviceLastUpdated`, `connPort`, `status`, `custom_Location`) VALUES ('1', 'Test1', '3', '3', 'on', '3', '1', '1.1.1.1', 'router#', '2', '1', '4431', '', '', 'admin', '1', '', '', '', '2016-04-17', '', '23', '1', '');
INSERT INTO `nodes` (`id`, `deviceName`, `deviceUsername`, `devicePassword`, `deviceEnableMode`, `deviceEnablePassword`, `deviceAccessMethodId`, `deviceIpAddr`, `devicePrompt`, `nodeCatId`, `vendorId`, `model`, `termLength`, `nodeVersion`, `nodeAddedBy`, `defaultCreds`, `defaultUsername`, `defaultPassword`, `defaultEnablePassword`, `deviceDateAdded`, `deviceLastUpdated`, `connPort`, `status`, `custom_Location`) VALUES ('2', 'test2', '3', '3', 'on', '3', '1', '1.1.1.1', 'router#', '2', '1', '4451', '', '', 'admin', '1', '', '', '', '2016-04-17', '', '23', '1', '');
INSERT INTO `nodes` (`id`, `deviceName`, `deviceUsername`, `devicePassword`, `deviceEnableMode`, `deviceEnablePassword`, `deviceAccessMethodId`, `deviceIpAddr`, `devicePrompt`, `nodeCatId`, `vendorId`, `model`, `termLength`, `nodeVersion`, `nodeAddedBy`, `defaultCreds`, `defaultUsername`, `defaultPassword`, `defaultEnablePassword`, `deviceDateAdded`, `deviceLastUpdated`, `connPort`, `status`, `custom_Location`) VALUES ('3', 'test3', 'router', 'router', 'on', 'router', '3', '1.1.1.1', 'router#', '2', '1', '2821', '', '', 'admin', '0', '', '', '', '2016-04-17', '', '22', '1', '');
INSERT INTO `nodes` (`id`, `deviceName`, `deviceUsername`, `devicePassword`, `deviceEnableMode`, `deviceEnablePassword`, `deviceAccessMethodId`, `deviceIpAddr`, `devicePrompt`, `nodeCatId`, `vendorId`, `model`, `termLength`, `nodeVersion`, `nodeAddedBy`, `defaultCreds`, `defaultUsername`, `defaultPassword`, `defaultEnablePassword`, `deviceDateAdded`, `deviceLastUpdated`, `connPort`, `status`, `custom_Location`) VALUES ('4', 'test4', 'router', 'router', 'on', 'router', '3', '1.1.1.1', 'router#', '2', '1', '1921', '', '', 'admin', '0', '', '', '', '2016-04-17', '', '22', '1', '');
INSERT INTO `nodes` (`id`, `deviceName`, `deviceUsername`, `devicePassword`, `deviceEnableMode`, `deviceEnablePassword`, `deviceAccessMethodId`, `deviceIpAddr`, `devicePrompt`, `nodeCatId`, `vendorId`, `model`, `termLength`, `nodeVersion`, `nodeAddedBy`, `defaultCreds`, `defaultUsername`, `defaultPassword`, `defaultEnablePassword`, `deviceDateAdded`, `deviceLastUpdated`, `connPort`, `status`, `custom_Location`) VALUES ('5', 'test5', 'router', 'router', 'on', 'router', '3', '1.1.1.1', 'router#', '2', '1', '7206', '', '', 'admin', '0', '', '', '', '2016-04-17', '', '22', '1', '');

-- TABLE: reportData
CREATE TABLE `reportData` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `device` varchar(255) DEFAULT NULL,
  `error` longtext,
  `script` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- TABLE: settings
CREATE TABLE `settings` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `fileSaveChk` int(10) DEFAULT NULL,
  `fileLocation` varchar(255) DEFAULT NULL,
  `defaultNodeUsername` varchar(255) DEFAULT NULL,
  `defaultNodePassword` varchar(255) DEFAULT NULL,
  `defaultNodeEnable` varchar(255) DEFAULT NULL,
  `useDefaultCredsManualSet` int(1) DEFAULT NULL,
  `commandDebug` int(10) DEFAULT '0' COMMENT '0 is default where 1 is debug on',
  `commandDebugLocation` varchar(255) DEFAULT NULL,
  `phpErrorLogging` int(2) DEFAULT '0',
  `phpErrorLoggingLocation` varchar(255) DEFAULT '/home/rconfig/logs/phpLog/',
  `deviceConnectionTimout` int(3) DEFAULT '10',
  `smtpServerAddr` varchar(255) DEFAULT NULL,
  `smtpFromAddr` varchar(255) DEFAULT NULL,
  `smtpRecipientAddr` longtext,
  `smtpAuth` tinyint(2) DEFAULT NULL,
  `smtpAuthUser` varchar(100) DEFAULT NULL,
  `smtpAuthPass` varchar(100) DEFAULT NULL,
  `smtpLastTest` varchar(20) DEFAULT NULL,
  `smtpLastTestTime` datetime DEFAULT NULL,
  `timeZone` varchar(100) DEFAULT NULL,
  `ldapServer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `settings` (`id`, `fileSaveChk`, `fileLocation`, `defaultNodeUsername`, `defaultNodePassword`, `defaultNodeEnable`, `useDefaultCredsManualSet`, `commandDebug`, `commandDebugLocation`, `phpErrorLogging`, `phpErrorLoggingLocation`, `deviceConnectionTimout`, `smtpServerAddr`, `smtpFromAddr`, `smtpRecipientAddr`, `smtpAuth`, `smtpAuthUser`, `smtpAuthPass`, `smtpLastTest`, `smtpLastTestTime`, `timeZone`, `ldapServer`) VALUES ('1', '1', '/home/rconfig/data/', '123443t34t34ghahdf', '123412334214214', '21431535325', '0', '0', '/home/rconfig/logs/debugging/', '1', '/home/rconfig/logs/phpLog/', '120', 'mail.eircom.net', 'admin@rconfig.com', 'stephenstack@gmail.com', '0', '', '', 'Passed', '2016-04-18 13:38:49', 'Europe/Dublin', '');

-- TABLE: snippets
CREATE TABLE `snippets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `snippetName` varchar(255) NOT NULL,
  `snippetDesc` varchar(255) NOT NULL,
  `snippet` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
INSERT INTO `snippets` (`id`, `snippetName`, `snippetDesc`, `snippet`) VALUES ('1', 'test snippet', 'test snip desc', 'afsafsafsafsaf');
INSERT INTO `snippets` (`id`, `snippetName`, `snippetDesc`, `snippet`) VALUES ('2', 'test snippet2', 'test snip 2 desc', 'yoyriotiotuotu');
INSERT INTO `snippets` (`id`, `snippetName`, `snippetDesc`, `snippet`) VALUES ('3', 'test snippet2', 'test snip 3 desc', 'yoyriotiotuotu');

-- TABLE: tasks
CREATE TABLE `tasks` (
  `id` int(6) NOT NULL,
  `taskType` int(3) NOT NULL,
  `taskname` varchar(255) NOT NULL,
  `taskDescription` varchar(255) NOT NULL,
  `snipId` int(10) DEFAULT NULL,
  `crontime` varchar(255) NOT NULL COMMENT 'e.g. 5 * * 6 *',
  `croncmd` varchar(255) NOT NULL COMMENT 'e.g. "php /script/script.php"',
  `addedBy` varchar(255) NOT NULL COMMENT 'for later use',
  `dateAdded` date NOT NULL,
  `catId` varchar(255) DEFAULT NULL COMMENT 'Used for Compare Reports Only',
  `catCommand` varchar(255) DEFAULT NULL COMMENT 'Used for Compare Reports Only',
  `status` int(2) NOT NULL COMMENT 'if 2 = deleted and not in crontab',
  `mailConnectionReport` int(10) DEFAULT '0',
  `mailErrorsOnly` int(10) DEFAULT '0',
  `complianceId` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- TABLE: userlevels
CREATE TABLE `userlevels` (
  `id` int(10) NOT NULL,
  `userlevel` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `userlevels` (`id`, `userlevel`) VALUES ('1', 'User');
INSERT INTO `userlevels` (`id`, `userlevel`) VALUES ('9', 'Administrator');

-- TABLE: users
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `userid` varchar(32) DEFAULT NULL,
  `userlevel` tinyint(1) unsigned NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `timestamp` int(11) unsigned NOT NULL,
  `status` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `users` (`id`, `username`, `password`, `userid`, `userlevel`, `email`, `timestamp`, `status`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'e08052e1e5df8320214262f03ea22318', '9', 'admin@domain.com', '1461152556', '1');

-- TABLE: vendors
CREATE TABLE `vendors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vendorName` varchar(50) DEFAULT '0',
  `vendorLogo` varchar(255) NOT NULL DEFAULT 'images/logos/Coding16.png',
  `status` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
INSERT INTO `vendors` (`id`, `vendorName`, `vendorLogo`, `status`) VALUES ('1', 'Cisco', ' images/vendor/cisco.jpg', '1');

